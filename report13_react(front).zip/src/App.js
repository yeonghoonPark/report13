import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Container, Nav, Card } from 'react-bootstrap';

// Header Component
function Header() {
  return (
    <header className="header">
      <div className="container">
        <Navbar bg="primary" variant="dark">
          <Container>
            <Navbar.Brand href="/"><h1>Travel's Blog</h1></Navbar.Brand>
            <Nav className="me-auto">
              <Nav.Link href="/">Home</Nav.Link>
              <Nav.Link href="/blog">Blog</Nav.Link>
              <Nav.Link href="/write">Write</Nav.Link>
            </Nav>
          </Container>
        </Navbar>
      </div>
    </header>
  );
}

// Banner Component
function Banner() {
  return (
    <section className="banner">
      <div className="container">
        <div className="background-banner">
          <h2>Travel's Blog Banner</h2>
        </div>
      </div>
    </section>
  );
}

// Blog & AD Component
function BlogAd() {
  return (
    <section className="blog-ad">
      <div className="container">
        <h3>blog-ad</h3>
        <div className="blog-box">
          <Card style={{ width: '18rem' }}>
            <Card.Body>
              <Card.Title>여행가들의 이야기</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up the bulk of content.
              </Card.Text>
              <Card.Link href="/blog">바로가기</Card.Link>
            </Card.Body>
          </Card>
        </div>
        <div className="ad-box">
          <p>AD</p>
        </div>
      </div>
    </section>
  );
}

// Footer Component
function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <address>
          Copyright by Park
        </address>
      </div>
    </footer>
  );
}

function App() {
  return (
    <div className="App">
      <div className="wrap">
        {/* HEADER */}
        <Header />

        {/* BANNER */}
        <Banner />

        {/* BLOG & AD */}
        <BlogAd />

        {/* FOOTER */}
        <Footer />
      </div>

    </div>
  );
}

export default App;
