// express
const express = require('express');
const req = require('express/lib/request');
const app = express();
// bodyparser
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ejs
app.set('view engine', 'ejs');

// middlewear
app.use(express.static(__dirname + '/build'));

// mongodb
const MongoClient = require('mongodb').MongoClient;

// mongodb 연동, server open
let travelDBUrl = 'mongodb+srv://admin:qwer1234@cluster0.pi799.mongodb.net/travelDB?retryWrites=true&w=majority';
let travelDB;
MongoClient.connect(travelDBUrl, (error, result) => {
    if (error) {
        return (
            console.log('MongoDB connection failed ', error)
        );
    }
    travelDB = result.db('travelDB');
    console.log('MongoDB connection success');

    app.listen(8080, () => {
        console.log('port opened success');
    })

})

// '/' = index.html
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
})

// '/blog' render
app.get('/blog', (req, res) => {
    travelDB.collection('travel').find().toArray((error, result) => {
        if (error) {
            return (
                console.log('DB search failed', error)
            );
        }
        res.render('blog.ejs', { travelData: result });
    })
})

// '/write' render
app.get('/write', (req, res)=>{
    res.render('write.ejs');
})

// '/add'로 post, mongodb client에 save
app.post('/add', (req, res) => {
    travelDB.collection('postcount').findOne({ total_count: 'total_count' }, (error, result) => {
        if (error) {
            return (
                console.log('total_count find failed', error)
            );
        }
        let totalCount = result.sequence_num;
        travelDB.collection('travel').insertOne({
            _id: totalCount + 1, title: req.body.title, content: req.body.content
        }, (error, result) => {
            if (error) {
                return (
                    console.log('travel save failed ', error)
                );
            }
            console.log('travelDB save success');
            travelDB.collection('postcount').updateOne({ total_count: 'total_count' }, { $inc: { sequence_num: 1 } }, (error, result) => {
                if (error) {
                    return (
                        console.log('total_count, sequence_num update failed', error)
                    );
                }
                res.redirect('/blog');
            })
        })
    });
})

// delete
app.delete('/delete', (req, res) => {
    travelDB.collection('travel').deleteOne({ _id: Number(req.body._id) }, (error, result) => {
        if (error) {
            return (
                console.log('travelDB delete failed', error)
            );
        }
        console.log('travelDB delete success');
    })
    res.redirect('/');
})